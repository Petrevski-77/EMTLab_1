package mk.ukim.finki.wplab.Repository;

import mk.ukim.finki.wplab.Model.Host;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HostRepository extends JpaRepository<Host, Long> {
}

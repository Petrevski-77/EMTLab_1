package mk.ukim.finki.wplab.Service;

import mk.ukim.finki.wplab.Model.Host;

import java.util.List;

public interface HostService {
    List<Host> findAll();
}

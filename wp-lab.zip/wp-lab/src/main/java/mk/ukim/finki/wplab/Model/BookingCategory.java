package mk.ukim.finki.wplab.Model;

public enum BookingCategory {
    ROOM,
    HOUSE,
    FLAT,
    APARTMENT,
    HOTEL,
    MOTEL
}
